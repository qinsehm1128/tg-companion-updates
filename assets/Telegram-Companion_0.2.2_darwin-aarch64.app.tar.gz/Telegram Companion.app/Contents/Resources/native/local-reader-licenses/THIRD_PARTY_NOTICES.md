# Local reader — third-party and format notices

The helper implementation is original Rust format decoding code. No Telegram
Swift, Telegram-iOS/Postbox, or tg-viewer source is distributed or translated
into this crate. Research source pins and compatibility limits are in README.md.
Historical TelegramSwift GPLv2 code was used only to verify the documented
external encrypted-container format; no official client initializers or routines
are included. The release owner should obtain legal review if this format-only
boundary or downstream distribution obligations change.

Exact transitive Cargo package versions, license declarations and supplied
license/notice text (including build/dev/other-target dependencies conservatively)
are in DEPENDENCY_LICENSES.txt. Keep that file with binary distribution. The
build script installs it into native/local-reader-licenses only on --install.

Important native dependencies:
- rusqlite 0.32.1 and libsqlite3-sys 0.30.1: MIT Rust wrappers/build logic.
- libsqlite3-sys includes SQLCipher's bundled amalgamation; its Zetetic BSD-style
  notice is preserved verbatim in DEPENDENCY_LICENSES.txt. It requires notice
  reproduction for binary redistribution and prohibits endorsement.
- openssl-src 300.6.1+3.6.3 vendors OpenSSL 3.6.3, Apache-2.0. Its LICENSE/NOTICE
  files are preserved as supplied. openssl-sys wrapper is MIT.
- RustCrypto aes/cbc/sha2 and zeroize: MIT OR Apache-2.0.
- Remaining runtime/build dependencies are permissive according to locked Cargo
  metadata; unicode-ident additionally carries Unicode-3.0. No GPL runtime code
  is introduced by this crate. SQLite's underlying public-domain statement does
  not replace SQLCipher's redistribution requirements.

This is a notice inventory, not a security certification or blanket legal opinion.
